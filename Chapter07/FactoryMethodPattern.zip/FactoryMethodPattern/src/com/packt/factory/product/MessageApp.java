package com.packt.factory.product;

public interface MessageApp {
	
	void sendMessage(String message);
}
