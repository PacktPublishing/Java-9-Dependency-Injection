package com.packt.factory.util;

public enum MessageType {

	SMSType,EmailType,WhatsAppType;
}
