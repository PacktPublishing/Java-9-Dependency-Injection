package com.packt.template.impl;

import com.packt.template.ProcessData;

public class ProcessXMLData extends ProcessData{

	@Override
	public void readFile() {
		System.out.println(" Reading Excel file");
	}
}
