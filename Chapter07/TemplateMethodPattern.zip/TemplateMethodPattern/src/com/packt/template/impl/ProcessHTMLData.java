package com.packt.template.impl;

import com.packt.template.ProcessData;

public class ProcessHTMLData extends ProcessData{

	@Override
	public void readFile() {
		System.out.println(" Reading HTML file");
	}
}
