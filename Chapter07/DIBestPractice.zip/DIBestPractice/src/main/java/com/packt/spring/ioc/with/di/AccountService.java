package com.packt.spring.ioc.with.di;
public class AccountService {
	//Service method.
	public void getVariablePay() {
		System.out.println("getting variable pay..");
	}
}
