package com.packt.locator.service;

public interface CompressionAlgorithm {

	void doCompress();
}
