package com.packt.locator.service;

public interface EncryptionAlgorithm {

	void doEncryption();
}
