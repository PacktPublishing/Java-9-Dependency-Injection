package com.packt.strategy.algorithm;

public class GoogleDriveCloud implements Cloud {

	@Override
	public void upload() {
		System.out.println(" Uploading on Google Drive ");
	}

}
