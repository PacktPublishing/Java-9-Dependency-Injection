package com.packt.strategy.algorithm;

public class OneDriveCloud implements Cloud {

	@Override
	public void upload() {
		System.out.println(" Uploading on OneDrive ");
	}

}
