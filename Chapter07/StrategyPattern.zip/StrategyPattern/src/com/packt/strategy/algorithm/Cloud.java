package com.packt.strategy.algorithm;

public interface Cloud {

	void upload();
}
