package com.packt.strategy.algorithm;

public class DropboxCloud implements Cloud {

	@Override
	public void upload() {
		System.out.println(" Uploading on Dropbox ");
	}

}
