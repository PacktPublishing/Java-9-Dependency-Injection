package com.packt.strategy.algorithm;

public class AmazoneS3Cloud implements Cloud {

	@Override
	public void upload() {
		System.out.println(" Uploading on Amazone S3 ");
	}

}
