package com.packet.spring.autowire.di;

public class EmailService {
	public void sendEmail() {
		System.out.println(" Sending Email ..!! ");
	}
}
