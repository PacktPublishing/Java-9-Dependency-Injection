package com.packet.spring.autowire.di;

public class StudentService {
	public void getStudentDetail() {
		System.out.println(" This is Student details.. ");
	}
}
