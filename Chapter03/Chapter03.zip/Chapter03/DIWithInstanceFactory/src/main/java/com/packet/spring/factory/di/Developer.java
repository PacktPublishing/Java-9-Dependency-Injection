package com.packet.spring.factory.di;

public class Developer extends Employee {
	public Developer(String type) {
		super(type);
	}
}
