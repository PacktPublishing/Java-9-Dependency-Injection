package com.packt.spring.aop.report.api;

public interface IExportPaySlip {
	
	public void export();

}
