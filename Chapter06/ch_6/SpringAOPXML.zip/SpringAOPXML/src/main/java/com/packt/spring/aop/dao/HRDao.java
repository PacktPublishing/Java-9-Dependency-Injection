package com.packt.spring.aop.dao;

public class HRDao {

	public void updateLeave() {
		System.out.println(" updating leave of employee.... ");
	}
}
