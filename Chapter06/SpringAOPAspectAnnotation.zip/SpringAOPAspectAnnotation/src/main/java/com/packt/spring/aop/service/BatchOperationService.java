package com.packt.spring.aop.service;

public class BatchOperationService {

	public void importCSVFile() {
		System.out.println("importing CSV File..");
	}
}
