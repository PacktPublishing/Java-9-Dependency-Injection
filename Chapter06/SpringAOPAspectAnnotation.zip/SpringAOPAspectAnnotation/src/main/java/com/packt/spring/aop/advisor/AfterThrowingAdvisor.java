package com.packt.spring.aop.advisor;

import org.springframework.aop.ThrowsAdvice;

public class AfterThrowingAdvisor implements ThrowsAdvice{

	

}
