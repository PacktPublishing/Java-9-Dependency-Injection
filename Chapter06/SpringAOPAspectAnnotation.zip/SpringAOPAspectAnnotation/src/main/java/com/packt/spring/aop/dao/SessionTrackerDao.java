package com.packt.spring.aop.dao;

public class SessionTrackerDao {

	public void updateLastLogin(long userId) {
		System.out.println("updating last login.... ");
	}
}
