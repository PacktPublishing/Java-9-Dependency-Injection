module com.packt.service.api {
	exports com.packt.service.api;
	uses com.packt.service.api.NotificationService;
}