module com.packt.client {
	requires com.packt.service.api;
}