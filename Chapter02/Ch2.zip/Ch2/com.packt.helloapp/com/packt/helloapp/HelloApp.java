package com.packt.helloapp;

public class HelloApp {

    public String sayHelloJava() {
		
      return "Hello Java 9 Module System";
	
	}

}