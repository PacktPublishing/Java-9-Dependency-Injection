package com.packt.java9.beanscope.beans;

public interface SingletonBeanScope {

}
