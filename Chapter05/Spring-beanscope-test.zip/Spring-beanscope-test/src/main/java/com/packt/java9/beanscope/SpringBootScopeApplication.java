package com.packt.java9.beanscope;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootScopeApplication{

	public static void main(String[] args) {
		SpringApplication.run(SpringBootScopeApplication.class, args);
	}

}
