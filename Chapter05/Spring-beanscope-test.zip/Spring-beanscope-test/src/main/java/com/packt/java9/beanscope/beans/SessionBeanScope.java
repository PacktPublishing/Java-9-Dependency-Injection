package com.packt.java9.beanscope.beans;

public interface SessionBeanScope {

	public void printClassDetail();

}
