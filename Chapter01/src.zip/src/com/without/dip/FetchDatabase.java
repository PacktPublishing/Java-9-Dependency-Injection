package com.without.dip;

import java.util.ArrayList;
import java.util.List;

public class FetchDatabase {

	public List<Object[]> fetchDataFromDatabase(){
        List<Object[]> dataFromDB = new ArrayList<Object[]>();
        //Logic to call database, execute a query and fetch the data
        return dataFromDB;
    }
}
