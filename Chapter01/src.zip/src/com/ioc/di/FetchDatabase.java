package com.ioc.di;

import java.util.ArrayList;
import java.util.List;

public class FetchDatabase implements IFetchData{
	
	public List<Object[]> fetchData(){
        List<Object[]> dataFromDB = new ArrayList<Object[]>();
        //Logic to call database, execute a query and fetch the data
        return dataFromDB;
    }
}
