package com.ioc.factory;

import java.util.List;

public interface IFetchData {

	//Common interface method to fetch data. 
    List<Object[]> fetchData();
}
