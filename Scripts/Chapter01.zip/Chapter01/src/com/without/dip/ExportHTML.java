package com.without.dip;

import java.io.File;
import java.util.List;

public class ExportHTML {
	
	public File exportToHTML(List<Object[]> dataLst){
        File outputHTML = null;
        //Logic to iterate the dataLst and generate HTML file.
        return outputHTML;
     }
}
