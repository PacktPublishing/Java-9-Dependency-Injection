package com.without.dip;

import java.io.File;
import java.util.List;

//Separate child module for export in PDF
public class ExportPDF {

	public File exportToPDF(List<Object[]> dataLst){
        File pdfFile = null;
        //Logic to iterate the dataLst and generate PDF file
        return pdfFile;
    }
}
