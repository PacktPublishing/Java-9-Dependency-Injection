package com.without.dip;

import java.util.ArrayList;
import java.util.List;

//Separate child module for fetch the data from web service.
public class FetchWebService {

	 public List<Object[]> fetchDataFromWebService(){
         List<Object[]> dataFromWebService = new ArrayList<Object[]>();
        //Logic to call Web Service and fetch the data and return it. 
        return dataFromWebService;
     }
}
