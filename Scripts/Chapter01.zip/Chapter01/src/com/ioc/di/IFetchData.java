package com.ioc.di;

import java.util.List;

public interface IFetchData {

	//Common interface method to fetch data. 
    List<Object[]> fetchData();
}
