package com.packet.spring.setter.di;

public class DocFinder {
	
	public void doFind() {
		System.out.println(" Finding in Document Base ");
	}

}
