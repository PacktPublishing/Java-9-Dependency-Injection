/**
 * 
 */
package com.packet.spring.annotation.factory.di;

/**
 * @author nilang.patel
 *
 */
public class Manager extends Employee {
	public Manager(String type) {
		super(type);
	}
}
