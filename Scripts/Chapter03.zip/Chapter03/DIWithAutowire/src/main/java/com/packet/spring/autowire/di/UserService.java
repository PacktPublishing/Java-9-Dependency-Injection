package com.packet.spring.autowire.di;

public class UserService {
	public void getUserDetail() {
		System.out.println(" This is user detail ");
	}
}
