package com.packt.hello.client;

import com.packt.helloapp.HelloApp;

public class HelloClient {

  public static void main (String arg[]) {

    HelloApp hello = new HelloApp();
    System.out.println(hello.sayHelloJava());
	
  }

}