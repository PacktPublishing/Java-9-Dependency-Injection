module com.packt.hello.client {
	requires com.packt.helloapp;
}