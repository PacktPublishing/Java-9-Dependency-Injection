package com.packt.services;

public interface NotificationService {

	boolean sendNotification(String message, String recipient);
}
